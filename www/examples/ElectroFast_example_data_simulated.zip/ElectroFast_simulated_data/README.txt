HOW TO TEST ELECTROFAST WITH THESE SIMULATED FILES
==================================================

Each file was made by a computer from values chosen in advance, so the right answer is known.
Load a file in the app, set the boxes as listed, and compare the app's result with the expected value.

Before you start: in the top right of the app, the "Instrument" box should say "Auto-detect from the file".

There are eight tests. Each takes a minute or two.


TEST 1. Electrode area from reversible CVs
------------------------------------------
Files: the four files in the CV_eChem folder whose names start with "CV_reversible"

  1. Top menu: Techniques > Cyclic voltammetry. Stay on the "Peaks and kinetics" sub-tab.
  2. "CVs, one or more scan rates": select all four CV_reversible files at once.
  3. "Forward peak on the last": choose "cathodic sweep".
  4. "Redox species": "In solution (diffusing)".
  5. "Electrons transferred (n)": 1.     "Concentration of the redox species (mM)": 1.
  6. "Diffusion coefficient": choose "Other (enter D)", then type 1e-5 in "D (cm²/s)".
  7. "Solve for": "Electroactive area (D known)".     "Randles-Sevcik form": "Reversible".
  8. Open the result tab "Area, D or coverage".

  Expected: area about 0.00985 cm². The true area is 0.0100 cm².
  (The files themselves carry a 1.5% shortfall from the simulation grid, so 0.00985 is the correct result for them.)

  Optional: in "Electrode", choose "Enter the area (cm²)" and type 0.01, then set "Solve for" to "D (area known)".
  Expected D: about 9.70e-6 cm²/s. The true D is 1.00e-5 (3% low, for the same reason).


TEST 2. Peaks, k⁰ and α from CVs with slow kinetics
---------------------------------------------------
Files: the eight files in the CV_eChem folder whose names start with "CV_psi"

  1. Same tab as Test 1, same settings (cathodic sweep, n = 1, 1 mM, D = 1e-5).
  2. "CVs, one or more scan rates": select all eight CV_psi files at once.
  3. Open the result tab "Peaks and k⁰" and read the table.

  The true k⁰ is in each file name (for example CV_psi_1_k0_0.01106 has k⁰ = 0.01106 cm/s). The true α is 0.50.
  The app should show:

    File            ΔEp (mV)  Regime            k⁰ Nicholson  k⁰ K table  k⁰ Klingler-Kochi  α
    CV_psi_20       60.5      reversible        -             -           -                  -
    CV_psi_7        62.9      reversible        0.0799        -           -                  -    (note: estimate)
    CV_psi_4        65.6      quasi-reversible  0.0471        0.0370      -                  0.53 (note: estimate)
    CV_psi_2        71.9      quasi-reversible  0.0238        0.0203      -                  0.51
    CV_psi_1        83.9      quasi-reversible  0.0118        0.0107      -                  0.50
    CV_psi_0.5      105.8     quasi-reversible  0.00563       0.00551     -                  0.50
    CV_psi_0.25     142.9     quasi-reversible  0.00254       0.00278     -                  0.50
    CV_psi_0.1      217.2     irreversible      -             -           0.00116            0.53 (from the peak width)

  What to look for: for ΔEp between about 70 and 150 mV, the k⁰ values are within about 8% of the true values.
  Closer to reversible (ΔEp below 70 mV), the app adds the note that k⁰ is only an estimate.

  Optional, quasi-reversible area: set "Randles-Sevcik form" to "Quasi-reversible, K(Lambda, alpha) per scan rate",
  load ONE CV_psi file at a time, and open "Area, D or coverage".
  Expected: area 0.0098 to 0.0099 cm² for every file from CV_psi_20 to CV_psi_0.25 (true 0.0100).
  CV_psi_0.1 is irreversible, and the app asks you to use the irreversible form.


TEST 3. Spikes (single-entity events)
-------------------------------------
Files: spikes_25_events.csv. The true values are in spikes_25_events_TRUE_VALUES.csv.

  1. Top menu: Techniques > Chronoamperometry. Click the "Single-entity spikes" button.
  2. Load spikes_25_events.csv.
  3. Keep the defaults: "Baseline: running median over (s)" 1, "Threshold: k x noise" 5,
     "Spike direction" Positive, "Join events closer than (s)" 0.
  4. Read the "Results" tab.

  Expected: 25 events, noise about 1.00 pA.
  The events table lists each spike's peak time, amplitude and charge. Compare them with the true-values file:
  times match, amplitudes are within 11%, charges are between 9% low and 0.5% high.


TEST 4. Steps (single-entity steps)
-----------------------------------
Files: steps_6_steps_10kHz.csv (25 MB, takes about 15 s to load). True values: steps_6_steps_TRUE_VALUES.csv.

  1. Techniques > Chronoamperometry. Click the "Single-entity steps" button.
  2. Load steps_6_steps_10kHz.csv.
  3. Keep the defaults: "Average the current in bins of (ms)" 10, "Window each side of a step (s)" 0.5,
     "Threshold: k x spread" 6, "Step direction" Both.
  4. Read the "Results" tab.

  Expected: 6 steps, at 10.3, 25.7, 41.2, 58.9, 77.4 and 96.1 s, with heights of 250, 40, 120, 25, 80 and -60 pA
  (each within about 1%). The 150 short spikes in the file should not be counted as steps.


TEST 5. Cottrell (diffusion coefficient after a potential step)
---------------------------------------------------------------
File: cottrell_D_7.6e-6.csv

  1. Techniques > Chronoamperometry. Click the "Cottrell" button.
  2. Load cottrell_D_7.6e-6.csv.
  3. "Fit from (s)" 0.5 and "to (s)" 5 (the defaults).     "Electrons transferred (n)" 1.
     "Concentration of the redox species (mM)" 1.
  4. "Electrode": "Standard disk (pick a size)", then the 2 mm disk.
  5. "Solve for": "D (area known)".

  Expected: D = 7.6e-6 cm²/s exactly (the file has no noise).
  Optional: choose "Diffusion coefficient: Ferricyanide, 7.6e-6 cm2/s" and "Solve for: Electroactive area (D known)".
  Expected area: 0.03142 cm² (the 2 mm disk).


TEST 6. Impedance circuit fit
-----------------------------
File: eis_randles_Rs100_Rct1000.csv

  1. Techniques > Impedance (EIS).
  2. Load eis_randles_Rs100_Rct1000.csv.
  3. Leave all circuits ticked under "Circuits to try" and click "Fit the circuits".
  4. Read the tabs "Kramers-Kronig check", "Circuit ranking" and "Fit".

  Expected:
  - Kramers-Kronig check: largest residual about 1.4% (the data are valid).
  - Circuit ranking: Rs-p(Q,Rct-W) first and recommended. This is the circuit the file was made from.
  - Fit (with Rs-p(Q,Rct-W) in "Circuit shown"): Rs 100.1 Ω, Q 2.02e-5, n 0.879, Rct 1003 Ω, sigma 296.
    The true values are Rs 100, Q 2e-5, n 0.88, Rct 1000, sigma 300.


TEST 7. Precision: repeatability, intermediate precision, reproducibility
--------------------------------------------------------------------------
Files: precision_8days_6electrodes.csv and precision_3labs_5days.csv

  1. Top menu: Sensor performance > Precision.
  2. Load precision_8days_6electrodes.csv (8 days x 6 electrodes x 3 readings).
  3. Read the Results table.

  Expected (true values in brackets):
    Repeatability 0.503 (0.5), between-day SD 1.94 (2), between-electrode SD 0.996 (1),
    intermediate precision 2.24 (2.29).

  4. Load precision_3labs_5days.csv (3 laboratories x 5 days x 6 electrodes x 3 readings).

  Expected: between-day 2.12 (2), between-electrode 1.10 (1), between-laboratory 2.28 (3), reproducibility 3.34 (3.77),
  and the note "Only 3 laboratory levels: the between-laboratory SD is indicative only". With so few laboratories
  the between-laboratory SD is uncertain, which is why the app warns.

  In these two files each set of day, electrode and laboratory effects was scaled so that its own SD equals the
  true value; the app's estimates still differ a little because the readings also carry the repeatability noise.

TEST 8. QC charts: Westgard rules across sessions
-------------------------------------------------
File: qc_history_2_quantities.csv (two quantities: the ECSA of a gold disk over 30 sessions, and an ISE slope over 25)

  1. Top menu: QC charts.
  2. "Load a QC history (CSV)": load qc_history_2_quantities.csv.
  3. "Reference period: first n sessions of each quantity": type 12.
  4. Read the line above the chart, the chart and the "Sessions" table.

  Expected line: "55 sessions, 2 quantities, 7 with a broken rule, 3 warnings."
  Limits table: ECSA mean 0.120, SD 0.006 cm². ISE slope mean 59.0, SD 0.40 mV/decade.
  The problems were planted at these sessions, and only these should be flagged:

    Quantity     Date         z      Rule              What was planted
    ECSA         2026-02-26   +3.6   1-3s              a single bad polish
    ECSA         2026-04-06   -1.9   4-1s              the area drifting down from 2026-03-19 (a wearing electrode)
    ECSA         2026-04-09   -1.7   4-1s
    ECSA         2026-04-13   -1.9   4-1s
    ECSA         2026-04-16   -1.8   4-1s
    ISE slope    2026-02-23   +2.4   1-2s (warning)    one high result on its own
    ISE slope    2026-03-09   +2.3   1-2s (warning)    the first of two high results in a row
    ISE slope    2026-03-12   +2.6   2-2s              the second of the two
    ISE slope    2026-03-19   +2.2   1-2s (warning)    a high result ...
    ISE slope    2026-03-23   -2.1   R-4s              ... followed by a low one, 4.3 SD apart

  Then clear the reference box (blank = all sessions). Expected: "3 with a broken rule, 0 warnings".
  The bad sessions now widen the SD themselves, so most problems are missed. This is why the reference period
  should hold only sessions known to be good.


HOW THE FILES WERE MADE
-----------------------
CVs (CV_eChem folder): the eChem R package (D. Harvey, CRAN, version 1.0.0), which is separate from ElectroFast.
  Model: one-electron reaction, Butler-Volmer kinetics, α 0.5, only the oxidised form in solution at the start,
  equal D for both forms, flat electrode, no charging current, no iR drop.
  Values: D 1e-5 cm²/s, 1 mM, area 0.01 cm², 25 °C, formal potential 0 V, sweep from +0.5 V to -0.5 V and back.
  Scan rate 0.1 V/s, except the four CV_reversible files (0.025, 0.05, 0.1 and 0.2 V/s).
  Current is written with oxidation positive, as in the CHI files.
  Limit: the simulation grid makes the peak currents about 1.5% low and ΔEp about 1.5 to 2 mV high.

Spikes: 60 s at 1 ms per point. Baseline 2 nA, slowly drifting. Random noise 1 pA. 25 triangular spikes, 10 ms wide,
  15 to 40 pA high.
Steps: 120 s at 10 kHz. Baseline 860 pA, rising 0.5 pA/s. Random noise 4 pA. Six steps, plus 150 short spikes
  (2 ms, 20 to 300 pA) that should not be counted as steps.
Cottrell: current after a potential step for a 2 mm disk, 1 mM, n = 1, D 7.6e-6 cm²/s, no noise.
Impedance: circuit Rs-p(Q,Rct-W) with the values in Test 6, 61 frequencies from 100 kHz to 0.1 Hz, 0.5% random noise.
Precision: value = 100 + day effect + electrode effect (+ laboratory effect) + random reading noise, with SDs 2, 1 (3) and 0.5
  (scripts/14_simulate_precision.R in ElectroFast).
QC history: values = mean + z x SD, where the first 12 sessions of each quantity were scaled to the mean and SD exactly,
  the planted sessions have the z values above, and the other sessions are random within 1.4 SD
  (scripts/18_simulate_qc_history.R in ElectroFast).

The spike, step, Cottrell and impedance files are the same data the ElectroFast test scripts build
(tests/check_spikes.R, check_steps.R and check_new_techniques.R). Every expected value above was checked by
loading these files into the app on 23 October 2026 (Tests 7 and 8 on 24 October 2026).
